create
    definer = root@localhost procedure getStockOnHand(IN param_item_id int) reads sql data
begin
    declare grn_q int;
    declare grrn_q int;
    declare invoice_q int;
    declare sr_q int;

    begin
        declare continue handler for not found
            begin
                set grn_q = 0;
            end;
        select
            sum(if(is_canceled=0, quantity, 0))
        into
            grn_q
        from inv_grns where item_id = param_item_id group by item_id;
    end;

    begin
        declare continue handler for not found
            begin
                set grrn_q = 0;
            end;
        select
            sum(if(is_canceled=0, returned_quantity, 0))
        into
            grrn_q
        from inv_grrns where item_id = param_item_id group by item_id;
    end;

    begin
        declare continue handler for not found
            begin
                set invoice_q = 0;
            end;
        select
            sum(if(is_canceled=0, quantity, 0))
        into
            invoice_q
        from inv_invoices where item_id = param_item_id group by item_id;
    end;

    begin
        declare continue handler for not found
            begin
                set sr_q = 0;
            end;
        select
            sum(if(is_canceled=0, quantity, 0))
        into
            sr_q
        from inv_sr where item_id = param_item_id group by item_id;
    end;

    select (grn_q - grrn_q + sr_q - invoice_q) as 'stock_on_hand';

end;

