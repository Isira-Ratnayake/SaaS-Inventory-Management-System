create definer = root@localhost view inv_po as
select `imsdb`.`po`.`po_number`      AS `po_number`,
       `imsdb`.`po`.`po_date`        AS `po_date`,
       `imsdb`.`po`.`is_canceled`    AS `is_canceled`,
       `imsdb`.`po`.`is_fulfilled`   AS `is_fulfilled`,
       `imsdb`.`po_items`.`item_id`  AS `item_id`,
       `imsdb`.`po_items`.`quantity` AS `quantity`
from (`imsdb`.`po` join `imsdb`.`po_items` on (`imsdb`.`po`.`po_number` = `imsdb`.`po_items`.`po_number`));

