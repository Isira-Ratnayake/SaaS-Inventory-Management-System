create definer = root@localhost view inv_grrns as
select `imsdb`.`grrn`.`grrn_number`                AS `grrn_number`,
       `imsdb`.`grrn`.`grrn_date`                  AS `grrn_date`,
       `imsdb`.`grrn_grn_item`.`grn_number`        AS `grn_number`,
       `imsdb`.`grrn_grn_item`.`item_id`           AS `item_id`,
       `imsdb`.`grrn`.`is_canceled`                AS `is_canceled`,
       `imsdb`.`grrn_grn_item`.`returned_quantity` AS `returned_quantity`
from (`imsdb`.`grrn_grn_item` join `imsdb`.`grrn`
      on (`imsdb`.`grrn_grn_item`.`grrn_number` = `imsdb`.`grrn`.`grrn_number`));

