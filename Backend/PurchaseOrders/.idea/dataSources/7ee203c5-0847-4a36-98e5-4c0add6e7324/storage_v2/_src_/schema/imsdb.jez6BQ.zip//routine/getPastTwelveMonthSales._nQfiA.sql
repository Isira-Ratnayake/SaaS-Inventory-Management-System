create
    definer = root@localhost procedure getPastTwelveMonthSales(IN param_item_id int) reads sql data
begin
        select
            item_id,
            month(invoice_date) as 'month_number',
            sum(quantity) as 'no_of_sales'
        from inv_invoices
        where item_id=param_item_id and invoice_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') - interval 12 month and invoice_date < DATE_FORMAT(CURDATE(), '%Y-%m-01')
        group by item_id, year(invoice_date), month(invoice_date) order by invoice_date desc;
    end;

