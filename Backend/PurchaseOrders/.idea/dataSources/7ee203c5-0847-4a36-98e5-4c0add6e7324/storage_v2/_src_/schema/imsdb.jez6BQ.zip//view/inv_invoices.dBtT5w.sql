create definer = root@localhost view inv_invoices as
select `imsdb`.`invoice`.`invoice_number`      AS `invoice_number`,
       `imsdb`.`invoice`.`invoice_date`        AS `invoice_date`,
       `imsdb`.`invoice`.`is_canceled`         AS `is_canceled`,
       `imsdb`.`invoice_grn_item`.`grn_number` AS `grn_number`,
       `imsdb`.`invoice_grn_item`.`item_id`    AS `item_id`,
       `imsdb`.`invoice_grn_item`.`quantity`   AS `quantity`
from (`imsdb`.`invoice` join `imsdb`.`invoice_grn_item`
      on (`imsdb`.`invoice`.`invoice_number` = `imsdb`.`invoice_grn_item`.`invoice_number`));

