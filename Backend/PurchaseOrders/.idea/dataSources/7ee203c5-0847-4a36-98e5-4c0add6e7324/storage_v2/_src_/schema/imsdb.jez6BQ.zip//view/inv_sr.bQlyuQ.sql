create definer = root@localhost view inv_sr as
select `imsdb`.`sr`.`invoice_number`      AS `invoice_number`,
       `imsdb`.`sr`.`sr_date`             AS `sr_date`,
       `imsdb`.`sr_grn_item`.`grn_number` AS `grn_number`,
       `imsdb`.`sr_grn_item`.`item_id`    AS `item_id`,
       `imsdb`.`sr`.`is_canceled`         AS `is_canceled`,
       `imsdb`.`sr_grn_item`.`quantity`   AS `quantity`
from (`imsdb`.`sr_grn_item` join `imsdb`.`sr`
      on (`imsdb`.`sr_grn_item`.`invoice_number` = `imsdb`.`sr`.`invoice_number`));

