create
    definer = root@localhost procedure getQuantityOnOrder(IN param_item_id int) reads sql data
begin
    declare po_q int;

        begin
        declare continue handler for not found
            begin
                set po_q = 0;
            end;
        select
            sum(if(is_canceled=0 and is_fulfilled=0, quantity, 0))
        into
            po_q
        from inv_po where item_id = param_item_id group by item_id;
    end;

    select po_q as 'quantity_on_order';
end;

