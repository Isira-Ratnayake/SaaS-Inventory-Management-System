create definer = root@localhost view inv_grns as
select `imsdb`.`grn`.`grn_number`    AS `grn_number`,
       `imsdb`.`grn`.`grn_date`      AS `grn_date`,
       `imsdb`.`grn`.`is_canceled`   AS `is_canceled`,
       `imsdb`.`grn_item`.`item_id`  AS `item_id`,
       `imsdb`.`grn_item`.`quantity` AS `quantity`
from (`imsdb`.`grn` join `imsdb`.`grn_item` on (`imsdb`.`grn`.`grn_number` = `imsdb`.`grn_item`.`grn_number`));

